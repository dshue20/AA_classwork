// kill spacerocks with this. also a MovingObject subclass
