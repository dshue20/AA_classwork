module.exports = {
  MONGO_URI:
    "mongodb+srv://zeus:FtGnUQtxIoHOXY6n@cluster0-esyoz.mongodb.net/test?retryWrites=true&w=majority"
};