module.exports = {
  MONGO_URI:"mongodb+srv://admin:cKpBXkeZTpd2AsGL@cluster0-btmj3.mongodb.net/greek_gods_two?retryWrites=true&w=majority"
};