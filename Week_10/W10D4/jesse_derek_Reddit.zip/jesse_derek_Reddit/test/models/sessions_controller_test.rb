require 'test_helper'

class SessionsControllerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
