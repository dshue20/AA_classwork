class Game {
    constructor() {

    }
}

module.exports = Game;