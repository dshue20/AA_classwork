require_relative "Pieces/piece"
require_relative "Pieces/rook"
require "byebug"
class Board
    
    attr_accessor :grid

    def initialize
        @grid = Array.new(8) {Array.new(8)}
        @grid.each_with_index do |row,idx|
            row.each_index do |idx2|
                if [0,1].include?(idx)
                    row[idx2] = Piece.new([idx,idx2], :black, self)
                elsif [6,7].include?(idx)
                    row[idx2] = Piece.new([idx,idx2], :white, self)
                else
                    row[idx2] = NullPiece.new
                end
            end
        end
    end

    def [](pos)
        row,col = pos
        grid[row][col]
    end

    def []=(pos,val)
        grid[pos[0]][pos[1]] = val
        #grid[pos] = val
    end

    def is_empty?(pos)
        return true if grid[pos].is_a?(NullPiece)
        false
    end

    def move_piece(start,finish)
        raise EmptyPosError if grid.is_empty?(start)
        raise InvalidMoveError if !@grid[pos].moves.include?(finish)
        @grid[finish] = @grid[start]
        @grid[start] = NullPiece.new
    end
    # white rook 1: [3,3]
    # moves: [[0,3],[1,3],[2,3],[4,3],[5,3],[6,3],[7,3]]
    # white rook 2: [5,3]


    def valid_move?(pos)
        if self[pos].is_a?(NullPiece)
            return true 
        else
            return self[pos].color
        end
    end

    def display
        print '  0 1 2 3 4 5 6 7'
        puts
        grid.each_with_index do |row,idx|
            print idx.to_s + ' '
            row.each do |square|
                if square.color 
                    print square.color[0].capitalize 
                    print ' '
                else
                    print '- '
                end
            end
            puts
        end
    end

end

class EmptyPosError < StandardError
end

class InvalidMoveError < StandardError
end

board = Board.new
rook1 = Rook.new([3,3],:white,board)
rook2 = Rook.new([5,3],:white,board)
#p board[[3,3]]
board[[3,3]] = rook1
board[[5,3]] = rook2
board.display
p rook1.possible_moves