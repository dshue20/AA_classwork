import {combineReducers} from 'redux';
import entities from './entities_reducer';

export default combineReducers({
    entities
})